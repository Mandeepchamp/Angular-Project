import { Component } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {
  empId:  number;
  empName: string;
  empSal : number;
  empDept : string;


  public addEmployee() 
  {
      alert(this.empId +" "+ this.empName +" "+this.empSal +" "+ this.empDept);
  }

}



