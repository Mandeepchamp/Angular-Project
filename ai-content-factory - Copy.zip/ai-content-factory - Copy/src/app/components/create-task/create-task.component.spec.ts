import {TestBed, waitForAsync} from '@angular/core/testing'

import {CreateTaskComponent} from './create-task.component'
import { QuillModule } from 'ngx-quill'

describe('Default component', () => {
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CreateTaskComponent,
        QuillModule.forRoot()
      ],
      providers: QuillModule.forRoot().providers
    }).compileComponents()
  }))

  it('test', () => {
    const fixture = TestBed.createComponent(CreateTaskComponent)

    expect(fixture).toBeDefined()
  })
})